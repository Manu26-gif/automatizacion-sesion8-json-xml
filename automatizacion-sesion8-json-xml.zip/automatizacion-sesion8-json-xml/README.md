# Automatizacion Sesion 8 - JSON y XML en Automatizacion de Redes

Practica de laboratorio: estructuracion y manipulacion de datos con JSON y XML.

## Archivos
- `ejercicio1_json.py` - Parseo de interfaces en JSON (json.loads / json.dumps)
- `dispositivos.xml` + `ejercicio2_xml.py` - Extraccion de jerarquias XML con ElementTree
- `routing_table.xml` + `conversion_xml_json.py` - Conversion XML -> JSON normalizado
- `routing_table_normalized.json` - Archivo generado por el script de conversion

## Ejecucion
```bash
py ejercicio1_json.py
py ejercicio2_xml.py
py conversion_xml_json.py
```
